CIS542 Lab6

Name: Yayang Tian
Worked Alone

SDK and Eclipse are used in ENIAC Machine

Note:  I implemented all the functions
I use Preference to store information
And, I add onPause and OnRestart to handle accidental incidence like answering a phone
